package TankGame;

import java.awt.*;
import javax.swing.*;

public class TankGameFrame extends JFrame {
	public TankGameFrame() {
		DrawTankPanle tdp = new DrawTankPanle();
		
		this.setTitle("Tank Game No War");
		this.setSize(400, 400);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setResizable(false);
		this.setVisible(true);
		
		this.add(tdp);
		
		this.addKeyListener(tdp);
	}
}
