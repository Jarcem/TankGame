package TankGame;

public class TankMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TankMain tm = new TankMain();
	}

	public TankMain() {
		TankGameFrame tgf = new TankGameFrame();
	}
}
