package TankGame;

import javax.swing.*;
import javax.swing.border.Border;

import java.awt.*;
import java.awt.event.*;

public class DrawTankPanle extends JPanel implements KeyListener {
	int coodinateX = 0, coodinateY = 0, direct = 0;

	public void paint(Graphics g) {
		super.paint(g);

		g.setColor(Color.black);
		g.fill3DRect(0, 0, 400, 300, false);

		g.setColor(Color.cyan);

		switch (direct) {
		case 0: {
			g.fill3DRect(coodinateX, coodinateY, 10, 40, false);
			g.fill3DRect(coodinateX + 10, coodinateY + 5, 20, 30, false);
			g.fillOval(coodinateX + 12, coodinateY + 12, 14, 14);
			g.drawLine(coodinateX + 18, coodinateY, coodinateX + 18,
					coodinateY + 20);
			g.drawLine(coodinateX + 19, coodinateY, coodinateX + 19,
					coodinateY + 20);
			g.drawLine(coodinateX + 20, coodinateY, coodinateX + 20,
					coodinateY + 20);
			g.fill3DRect(coodinateX + 30, coodinateY, 10, 40, false);
		}
			break;
		case 1: {
			g.fill3DRect(coodinateX, coodinateY, 10, 40, false);
			g.fill3DRect(coodinateX + 10, coodinateY + 5, 20, 30, false);
			g.fillOval(coodinateX + 12, coodinateY + 12, 14, 14);
			g.drawLine(coodinateX + 18, coodinateY + 40, coodinateX + 18,
					coodinateY + 20);
			g.drawLine(coodinateX + 19, coodinateY + 40, coodinateX + 19,
					coodinateY + 20);
			g.drawLine(coodinateX + 20, coodinateY + 40, coodinateX + 20,
					coodinateY + 20);
			g.fill3DRect(coodinateX + 30, coodinateY, 10, 40, false);
		}
			break;
		case 2: {
			g.fill3DRect(coodinateX, coodinateY, 40, 10, false);
			g.fill3DRect(coodinateX + 5, coodinateY + 10, 30, 20, false);
			g.fillOval(coodinateX + 12, coodinateY + 12, 14, 14);
			g.drawLine(coodinateX, coodinateY + 18, coodinateX + 18,
					coodinateY + 20);
			g.drawLine(coodinateX, coodinateY + 19, coodinateX + 19,
					coodinateY + 20);
			g.drawLine(coodinateX, coodinateY + 20, coodinateX + 20,
					coodinateY + 20);
			g.fill3DRect(coodinateX, coodinateY + 30, 40, 10, false);
		}
			break;
		case 3: {
			g.fill3DRect(coodinateX, coodinateY, 40, 10, false);
			g.fill3DRect(coodinateX + 5, coodinateY + 10, 30, 20, false);
			g.fillOval(coodinateX + 12, coodinateY + 12, 14, 14);
			g.drawLine(coodinateX + 40, coodinateY + 18, coodinateX + 18,
					coodinateY + 20);
			g.drawLine(coodinateX + 40, coodinateY + 19, coodinateX + 19,
					coodinateY + 20);
			g.drawLine(coodinateX + 40, coodinateY + 20, coodinateX + 20,
					coodinateY + 20);
			g.fill3DRect(coodinateX, coodinateY + 30, 40, 10, false);
		}
			break;
		}
		g.setFont(new Font("����", Font.BOLD, 15));
		g.setColor(Color.red);
		g.drawString("X����"+coodinateX, 0, 315);
		g.drawString("Y����"+coodinateY, 200, 315);
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		switch (e.getKeyCode()) {
		case KeyEvent.VK_UP: {
			if (direct == 0) {
				if (coodinateY > 0) {
					coodinateY -= 2;
				} else {
				}
			} else {
				direct = 0;
			}
		}
			break;
		case KeyEvent.VK_DOWN: {
			if (direct == 1) {
				if (coodinateY < 260) {
					coodinateY += 2;
				} else {
				}
			} else {
				direct = 1;
			}
		}
			break;
		case KeyEvent.VK_LEFT: {
			if (direct == 2) {
				if (coodinateX > 0) {
					coodinateX -= 2;
				} else {
				}
			} else {
				direct = 2;
			}
		}
			break;
		case KeyEvent.VK_RIGHT: {
			if (direct == 3) {
				if (coodinateX < 360) {
					coodinateX += 2;
				} else {
				}
			} else {
				direct = 3;
			}
		}
			break;
		}
		this.repaint();
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub

	}
}